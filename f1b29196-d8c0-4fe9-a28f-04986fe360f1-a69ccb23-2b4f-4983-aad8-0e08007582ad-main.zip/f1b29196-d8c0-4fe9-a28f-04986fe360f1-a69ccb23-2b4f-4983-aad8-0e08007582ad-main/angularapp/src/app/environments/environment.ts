export const environment = {
    apiUrl: 'https://8080-aadbcafeabacdcacbdfdffcacbbeaaccbbfaadead.premiumproject.examly.io'
}