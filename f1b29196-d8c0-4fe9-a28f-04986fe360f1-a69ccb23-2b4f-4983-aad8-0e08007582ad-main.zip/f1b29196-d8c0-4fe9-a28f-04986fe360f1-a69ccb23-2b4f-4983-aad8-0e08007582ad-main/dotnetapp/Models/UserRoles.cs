using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace dotnetapp.Models
{
    public class UserRoles
    {
        public const string User="User";
        public const string Nutritionist="Nutritionist";
    }
}