# f1b29196-d8c0-4fe9-a28f-04986fe360f1-a69ccb23-2b4f-4983-aad8-0e08007582ad
https://sonar.server.examly.io/dashboard?id=iamneo-production-2_f1b29196-d8c0-4fe9-a28f-04986fe360f1-a69ccb23-2b4f-4983-aad8-0e08007582ad&amp;codeScope=overall
